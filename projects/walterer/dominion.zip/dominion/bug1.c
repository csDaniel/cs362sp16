/* The bugs that I found were the ones that I introduced during the refactor
assignment */

/* Smithy - The player did not receive the proper number of cards. The player should
have received 3 cards but instead drew 4 due to the bug I introduced. The test found
this bug*/

/* Adventurer - There was a bug here with the amount discarded. I reduced the number
of cards that were discarded by 1. So, the test discovered it and it failed*/

/* Village - There was a bug with the incrementing of actions. I introduced this bug.
The player should have gotten 2 additional actions but the player only got 1. My test
discovered this*/

/* Great Hall - here was a bug with the incrementing of actions. I introduced this bug.
The player should have gotten 1 additional actions but the player got 2. My test
discovered this*/


