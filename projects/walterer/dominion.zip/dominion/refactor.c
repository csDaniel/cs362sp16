/*

Eric Walters

	playAdventurer: In while(z-1) statement, I changed temphand[z-1] to temphand[z]
	so that there is an extra card
	
	playSmithy: Changed the iterations to 4 so they player can draw 4 cards
	when playing the Smithy
	
	playVillage: Changed the number of actions to +1 so the player only gets
	to make 1 additional actions as opposed to two
	
	playGreatHall: Added an action for the player so the person who uses the card
	gets an additional action
	
	playCouncil_Room: Added 4 to the Buy so that the player gets 3 more buys than
	they are expecting


*/